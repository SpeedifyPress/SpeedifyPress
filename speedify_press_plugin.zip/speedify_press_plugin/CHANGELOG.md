# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

### 0.81.0 - 2026-04-08
This release is a major packaging, build, compliance, and edition-separation update.

#### Added
- Added a full `admin_app/` source workspace (Vue + Vite + Tailwind + docs/components) so human-readable admin source is now included in-repo and buildable.
- Added `admin_app/vite.config.js` with community build constants and aliasing (`@pro-admin-items` -> `proAdminItems.stub.js`) to keep non-pro builds build-safe.
- Added `admin_app/update_release.php` release tooling to generate release metadata/docs from source and changelog.
- Added root `composer.json` and `patches.lock.json` to make dependency patching reproducible for non-pro distributions.
- Added `vendor/patches/*` patch set for WP.org lint/compliance compatibility:
  - Sabberworm escaping/type fixes.
  - MatthiasMullie Minify escaping + alt-function handling.
  - simplehtmldom compliance/direct-access guards.
  - Wa72 URL parse compatibility patch.
- Added `readme.wordpressorg.txt` with WP.org-specific plugin metadata, FAQ, changelog placeholder, and feature framing.
- Added `src/App/LicenseIntegration.php` as the licensing integration boundary (hooks/routes/plugin API/update rows moved behind an integration class).
- Added bootstrap-safe request helpers in `Speed`:
  - `sanitize_bootstrap_text()`
  - `sanitize_bootstrap_url()`
  - `server_var()`
  - `safe_parse_url()`
  - `delete_file_compat()`
  - `get_query_args()`
  - `request_has_query_arg()`
  - `get_current_host()`
  - `is_same_origin_url()`
  - `make_absolute_host_url()`
- Added extension hook dispatch model in `Speed`:
  - `call_extension()` + `__callStatic()` fallback, replacing hard-coded Pro-method wrappers.
- Added direct-access guards (`if ( ! defined('ABSPATH') ) exit;`) across additional plugin runtime classes.
  - `/check_license` registration moved behind `LicenseIntegration::register_rest_routes()`.
  - `check_license()` now delegates to `LicenseIntegration` when available.
  - Plugin-enable flow validates licensing via integration module when present.
- Hardened public CSS update endpoint:
  - Added strict Origin/Referer validation.
  - Added same-origin validation for submitted URL.
  - Added early skip response when URL lookup already processed.
  - Improved client IP sanitization for rate limiting.
- Updated `handle_compressx()` to use `WP_REST_Request` params instead of raw `$_GET`.
- Updated cache/bootstrap flow to use sanitized server/request accessors and compatibility helpers in advanced cache context.
- Updated config update flow for `preload_fonts_intelligently` so dependent keys are expanded before save loop (fixes shortcut persistence timing issue).
- Updated path/file operations toward WP-compatible functions where applicable (`wp_mkdir_p`, `wp_delete_file`, filesystem-backed directory removal helper).
- Updated plugin header/release metadata:
  - `speedify_press.php` version moved to `0.80.07` in staged set.
- Updated cache bypass globals and naming for safer namespace isolation (e.g. `spress_bypass_reason`, `spress_cache_purging`, `spress_start_time`).
- Updated many URL parsing calls to `wp_parse_url` (or compatibility wrapper in early bootstrap paths).
- Updated timestamp/log usage in multiple paths to GMT (`gmdate`) consistency.
- Updated `unused` CSS pipeline remote fetch behavior to enforce same-origin safety and tighter local path resolution.

#### Removed
- Removed logged-in cache worker and Woo nonce helper assets from package.
- Removed config entries tied to removed pro-only cache nonce replacement paths.
- Removed large simplehtmldom bundled non-runtime docs/examples/manual content from shipped tree.
- Removed legacy output-buffer debug error-handler override in `Speed` callback path.

#### Fixed
- Fixed trailing slash handling regression in sanitized URI normalization.
- Fixed multiple escaped-output and type issues that triggered WP.org lint errors in dependency code paths.
- Fixed dashboard/community/wordpress.org license-mode rendering and fallback behavior via integration-aware data flow.
- Fixed advanced-cache response output handling to avoid unsafe direct output warnings while preserving raw cache body/gzip responses.

#### Security / Compliance
- Tightened request sanitization throughout cache/bootstrap paths (`$_SERVER`, cookies, headers, query parsing).
- Added same-origin protection in endpoints that accept URL input.
- Added direct file access protection in additional dependency/runtime files.
- Introduced maintained patch pipeline so dependency compliance edits are reapplied consistently on rebuild.
- Continued replacement of raw superglobal access patterns with validated/sanitized wrappers for WP.org review readiness.

#### Developer / Build Notes
- Non-pro build now depends on included `admin_app` source and local Vite build pipeline.
- Dependency compliance changes are now tracked in `vendor/patches/*` + `patches.lock.json`, not as ad-hoc manual edits.
- Licensing concerns are now encapsulated in `LicenseIntegration` + `LicenseService`, reducing edition-specific scatter in core runtime.

### 0.80.6 - 2026-01-28
- Strip collector + Turnstile scripts and hints on processed pages

### 0.80.5 - 2026-01-27
- Add Turnstile protection for public CSS update endpoint with admin UI + docs
- Enforce same-origin, Origin+Referer checks, and skip redundant update_css processing
- Harden CSRF token header handling for advanced cache context
- Tighten URL fetch safety in Unused CSS pipeline

### 0.80.4 - 2026-01-25
- Fix bug in calling is_shop

### 0.80.3 - 2026-01-23
- Fix dates in changelog

### 0.80.2 - 2026-01-23
- Fix template/content loading order

### 0.80.1 - 2026-01-22
- Make font lazy load interaction only
- Fix undelayed JS loading before template restore
- License tweaks
- Disable plugin in customizer

### 0.80.0 - 2026-01-17
- Add Bloat remover
- Create community/pro editions
- Update Cloudflare worker
- Update licensing DB sructure
- Refactor JSDelayer, add ability to set individual delay times on scripts
- Add ability to force JS inline
- Add Bloat Removal
- Fix non serving of CSRF if cache not enabled

### 0.78.7 - 2026-01-10
- Minimize sidebar width

### 0.78.6 - 2026-01-10
- Allow CSRF to be served from main plugin

### 0.78.5 - 2026-01-08
- Allow individual scripts to have diff delay times

### 0.78.4 - 2025-12-16
- JS checkbox options disappearing
- Notice/deprecation messages
- Permalinks warning isn't shown anywhere
- Docs Updates

### 0.78.3 - 2025-12-11
- Restore replays trigger

### 0.78.2 - 2025-12-11
- Adjust default completion triggers
- Fix checkbox booleans

### 0.78.1 - 2025-12-11
- Adjust default completion triggers

### 0.78.0 - 2025-12-11
- Full flexibility and backwards compat for completion triggers

### 0.77.6 - 2025-12-05
- Don't preload data URIs

### 0.77.5 - 2025-12-04
- Rework of JS delay script

### 0.77.4 - 2025-12-04
- Tweak load order for captured events

### 0.77.3 - 2025-12-04
- Tighten up captured event firing with patched event listener

### 0.77.2 - 2025-12-03
- Fix double replay with document load

### 0.77.1 - 2025-12-03
- Only run triggers if not already run

### 0.77.0 - 2025-12-03
- Add configurable events and triggers

### 0.76.0 - 2025-12-02
- Updates to Readme
- Slimming package size
- Add document onload setting to JS
- Tidy Cloudflare docs
- Reduce CSRF request frequency

### 0.75.2 - 2025-12-01
- Remove patching lib from production release

### 0.75.1 - 2025-11-30
- Log when no LCP found

### 0.75.0 - 2025-11-29
- Prevent use of DOMDocument (segfault)

### 0.74.0 - 2025-11-28
- Add CompressX easy install

### 0.73.0 - 2025-11-25
- Add main panel expand for easier code editing

### 0.72.3 - 2025-11-24
- JS old version compatibility
- Increase CSS request limit 
- Add page template tags
- Improve cached uris list
- Allow user to add font filenames

### 0.72.2 - 2025-11-20
- Allow CSS to be collected even with logged in caching

### 0.72.1 - 2025-11-20
- Fix CSRF for domains in subfolders

### 0.72.0 - 2025-11-20
- Allow turning off of all AJAX nonces

### 0.71.0 - 2025-11-20
- Update to licensing system

### 0.70.2 - 2025-11-18
- Tweak to icon font identification

### 0.70.1 - 2025-11-17
- Add cookie fallback for CSRF token

### 0.70.0 - 2025-11-14
- Remove CSRF replacement from CF worker
- Add Woo nonce replacement
- Add improvements to CSRF token generation
- Ensure templates are replaced before JS runs
- Add page preloads/prerenders
- Update Sabberworm version
- Move vendor to dependencies
- Create patch for HtmlNode charset    

### 0.67.0 - 2025-10-23
- Unused CSS tweaks to handle glitched CSS

### 0.67.0 - 2025-10-22
- Add page preloading
- Fix double find replace
- Forced image lazyloads
- Admin menu restructure

### 0.66.7 - 2025-10-17
- Unused fonts fixes

### 0.66.5 - 2025-10-16
- Mobile font fixes
- Activation compatibility checks

### 0.66.4 - 2025-10-15
- Fix debugging in Unused
- Fix admin bar nonce timeout
- Fix protocol relative Google fonts

### 0.66.3 - 2025-10-15
- Fixes for rest nonce expiring

### 0.66.2 - 2025-10-14
- Fixes to Unused class
- Fixes for purging on post save
- Fixes for rest nonce

### 0.66.1 - 2025-10-14
- Fix nonce expiry
- Correct bug after removal of page headers

### 0.66.0 - 2025-10-12
- Add code insertion

### 0.65.1 - 2025-10-11
- Tweaks to Find/Replace

### 0.65.0 - 2025-10-06
- Add nonces and tighten security practices

### 0.64.7 - 2025-10-06
- Big fixes to caching. JS, CSS

### 0.64.6 - 2025-10-04
- Allow find/replace by CSS selector

### 0.64.5 - 2025-10-02
- Fixes for CSS vars
- Fixes for JS modules delay
- Fixes for LCP preloading

### 0.64.4 - 2025-09-30
- Tweaks to code editor display

### 0.64.3 - 2025-09-30
- Tweaks to icon font finding

### 0.64.2 - 2025-09-28
- Tweaks to find/replace display

### 0.64.1 - 2025-09-28
- Updates to footer display

### 0.64.0 - 2025-09-27
- Fixes for CF worker redirect handling
- Add code highlighting
- Improvements and fixes for logged-in caching
- Add Multisite Compatibility
- Add icon font lazyloading
- Improve CSS selector force includes handling
- Tighten up caching rules

### 0.63.2 - 2025-09-08
- Fixes for usage collector on incongnito

### 0.63.1 - 2025-09-08
- Fixes for conditional font display
- Fixes for usage collector on incongnito

### 0.63.0 - 2025-09-08
- Add local hosting of Google fonts
- Add preloading of poster image for videos
- Fix license expiry incorrectly stored
- Save all font definitions in single file to allow for desktop only preload

### 0.62.4 - 2025-08-28
- Cache clearance with integrations fix

### 0.62.3 - 2025-08-28
- CSRF expiry bug fix

### 0.62.2 - 2025-08-28
- Gzip output bug fix

### 0.62.1 - 2025-08-28
- Cache directory bug fix

### 0.62.0 - 2025-08-28
- Allow change to cache directory
- Allow optional gzip output
- Optimise cache clearance

### 0.61.0 - 2025-08-28
- Addition of CSS security options
- Add ID to google gtag filename

### 0.60.1 - 2025-08-17
- Further tweaks to Cloudflare worker

### 0.60.0 - 2025-08-07
- Improvements to logged-in user cache 
- Further tweaks to Cloudflare worker
- Collapseable sidebar
- Remove reliance on text/html request header
- Correct writing to advanced cache
- Don't parse XML documents

### 0.59.0 - 2025-08-04
- Cloudflare worker improvements

### 0.58.0 - 2025-07-11
- Licensing tweaks
- Improvements to intersection observer
- Minor bug fixes to delay.js
- Turn off debugging on usage collector
- Better disable for builder keywords
- Better View Details link in plugin display
- Improved cache deletion

### 0.57.1 - 2025-06-10
- Licensing hotfixes

### 0.57.0 - 2025-06-10
- Fixes:
    - Licensing text
    - Template content restoration reliability
    - Usage collector ignoring external styles
    - RestAPI typo
    - CSS increased reliability
    - Kinsta increased reliability
    - UnusedCSS better handle font variables

### 0.56.1 - 2025-06-04
- Fix: minor licensing fixes

### 0.56.0 - 2025-06-04
- Fix: Stylesheet media attributes should be taken into account
- Feat: A free plan is required

### 0.55.0 - 2025-05-27
- Fix: Code incorrectly being added to the head #20
- Fix: Unused CSS missing URLs that don't start with http(s) #21
- Fix: Correctly set allowed hosts to 0 when required #22
- Fix: CSRF token should expire after 30 seconds #23

### 0.54.2 - 2025-05-08
- Fix: Cache clear should remove empty dirs

### 0.54.1 - 2025-05-08
- Fix: dates should be added to changelog

### 0.54.0 - 2025-05-08
- Fix: fixes required for license handling

### 0.53.0 - 2025-05-07
- Feat: Cloudflare worker should ignore kinsta uptime bot 
- Fix: Cache should correctly strip querystrings 
- Tidy: README amends

### 0.52.0 - 2025-05-06
- Update usage collecttor for inline CSS

### 0.51.0 - 2025-05-06
- Fix PHP Warnings

### 0.50.0 - 2025-05-06
- Allow Unicode text to be saved from settings fields

### 0.49.0 - 2025-04-27
- Add quick copy for Cloudflare settings
- Improvements to documentation

### 0.48.0 - 2025-04-25
- Various improvements to harden plugin security

### 0.47.0, 0.47.1, 0.47.2 - 2025-04-17
- Update README.md

### 0.46.0 - 2025-04-15
- Check license by invoice number, not email

### 0.45.0 - 2025-04-10
- Add Inline, grouped CSS setting
- Update Cloudflare worker to ignore API paths
- Improve onload to handle down-page loads
- Fix CSS cache purge issue
- Improve inline CSS animation detection

### 0.44.0 - 2025-04-07
- Fixes to clear buttons not always working

### 0.43.0
- Add number of hosts to licensing check

### 0.42.1
- Tweak font detection function

### 0.42.0
- Add option to prevent icon fonts from preloading

### 0.41.0
- csrf fixes for Unused CSS function

### 0.40.0
- Move Unused processing to backend

### 0.39.1
- Font preloading tweaks

### 0.39.0
- Font preloading options

### 0.38.1
- Full and partial disabling of plugin also in advanced-cache.php

### 0.38
- Allow full and partial disabling of plugin

### 0.37
-  Fixes:
    - Uninstall doesn't remove advanced-cache.php
    - Advanced-cache should exit if autoload not found
    - speed_css_vars should be updated in cached files when changhed
    - When you save a skip reload image it removes the Current image from preload
    - Find/replace not working to replace in spress-inlined

### 0.36
-  Add page caching class and options

### 0.35.1
-  Further updates to licence system

### 0.35.0
-  Update to licence system

### 0.34.0
-  Version bump

### 0.33.0
-  Rename to SpeedifyPress complete
-  Add licensing functionality
-  Fixes to backend UI maintaining global data
-  Updates to docs

### 0.32.0
-  Rename to SpeedifyPress

### 0.31.0
-  Add ability to generate at specific resolutions

### 0.30.0
-  Various fixes and improvements

### 0.29.0
-  Add global find/replace functionality

### 0.28.0
-  Reorganise structure, add font and lcp image preloading

### 0.27.0
-  Add onload callback

### 0.26.0
-  Add Javascript defer and delay

### 0.25.0
-  Improve tagging function

### 0.24.0
-  Improvements to font collection

### 0.23.0
-  Add additional optimisation options

### 0.22.0
-  Resolve nested CSS variables

### 0.21.0
-  Improve templates and onload

### 0.20.0
-  Sort correct onload position

### 0.19.0
-  Further standin improvements, better gtag replacement

### 0.18.0
-  Improvements to jQuery standin, onload script runs correct place

### 0.17.0
-  Improvements to CSS optimisation code

### 0.16.0
-  Improve CSS handling

### 0.15.0
-  Change local file folder and filename

### 0.14.0
-  Add local gtag handling

### 0.13.0
-  Add automatic content lazy rendering

### 0.12.0
-  Add jQuery standin, only load partytown if required

### 0.11.0
-  Add partytown, inline CSS and improved document taggins

### 0.10.0
-  Make intersection obsever immediate load

### 0.10.0
-  Cleanup, improve scroll collect 

### 0.09.0
-  Add constrain intrinsic, admin UI improvements

### 0.08.0
-  Add ability to ignore certain URLs or cookies for CSS

### 0.07.0
-  Fix count of {slug} URLs

### 0.06.0
- Improvements to the stats area, cosmetic changes

### 0.05.0
- Increment lookups rather than replace

### 0.04.0
- Unminify PHP

### 0.03.0
- Update logo, minify PHP

### 0.02.0
- Set correct image width

### 0.01.0
- Initial commit
