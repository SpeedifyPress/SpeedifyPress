/**
 * JsDelayer class for managing script loading based on user interaction or timeout.
 */
class JsDelayer {

    static _addListenerPatched = false;
    static captureEvents = ["readystatechange", "DOMContentLoaded", "load"];
    static captured = {
        readystatechange: [],
        DOMContentLoaded: [],
        load: []
    };
    static capturing = false;

    static nativeAdd     = EventTarget.prototype.addEventListener;
    static nativeWinAdd  = window.addEventListener;
    static nativeDocAdd  = document.addEventListener;

    static patchedAddEventListener(type, listener, options) {
        const cfg = window.speed_js_vars || {};
        const tni = cfg.trigger_native_interception || {};
        const isWin = this === window;
        const isDoc = this === document;
        let kind, key;

        const validListener = typeof listener === "function" || (listener && typeof listener === "object" && typeof listener.handleEvent === "function");
        if (!validListener) {
            return;
        }        

        if (type === "DOMContentLoaded") kind = "dom";
        else if (type === "load") kind = "load";
        else if (type === "readystatechange") kind = "readystate";

        if (kind && (isWin || isDoc) && JsDelayer.capturing) {
            key = isWin ? "window" : "document";
            if (tni[kind] && tni[kind][key] === "true") {
                JsDelayer.captured[type].push({ target: this, listener, options });
                return;
            }
        }

        if (this === window) {
            return JsDelayer.nativeWinAdd.call(window, type, listener, options);
        }

        if (this === document) {
            return JsDelayer.nativeDocAdd.call(document, type, listener, options);
        }

        return JsDelayer.nativeAdd.call(this, type, listener, options);
    }

    static ensurePatchedAddListener() {
        if (JsDelayer._addListenerPatched) return;
        JsDelayer._addListenerPatched = true;
        EventTarget.prototype.addEventListener = JsDelayer.patchedAddEventListener;
        window.addEventListener = JsDelayer.patchedAddEventListener;
        document.addEventListener = JsDelayer.patchedAddEventListener;
    }

    /**
     * Constructs a JsDelayer instance.
     * @param {string} load_first - Scripts to load first, separated by newline.
     * @param {string} load_last - Scripts to load last, separated by newline.
     * @param {number} timeout - Timeout in seconds to wait before loading scripts.
     * @param {boolean} debug - Enable or disable debugging.
     * @param {Array|NodeList|null} source_nodes - Optional list of nodes to manage.
     * @param {boolean} attach_listeners - Whether this instance attaches interaction + timeout listeners.
     * @param {boolean} finalize - Whether to run post-load lifecycle (replays, rerun loader, events).  
    */
    constructor(load_first = "", load_last = "", timeout = 3, callback = false, debug = false, source_nodes = null, attach_listeners = true, finalize = true) {         
        this.loadFirst = new Set(this.parseList(load_first));
        this.loadLast = new Set(this.parseList(load_last));
        this.timeout = timeout * 1000;
        this.debug = debug;
        this.sourceNodes = source_nodes;
        this.attachListeners = attach_listeners;
        this.finalize = finalize;        
        this.callback = callback;
        this.callback_run = false;
        this.hasTriggeredEvents = false;
        this._loading = false;

        this.savedClicks = new Set();
        this.savedMouseovers = new Set();

        this.interactionEvents = ["click","mouseover", "keydown", "touchstart", "touchmove", "wheel"];

        this.armStartTriggers();
    }

    /**
     * Parses a list of items separated by newline.
     * @param {string} listString - String containing items separated by newline.
     * @returns {Array} - Array of parsed items.
     */
    parseList(listString) {
        const list = listString.split("\n").filter((item) => item.trim() !== "");
        if (this.debug) {
            console.log("Parsed list:", list);
        }
        return list;
    }

    /**
     * Arms start conditions (interaction + timeout).
     */
    armStartTriggers() {

        if (this.debug) {
            console.log("JsDelayer initialized.");
            console.log("Load first scripts:", Array.from(this.loadFirst));
            console.log("Load last scripts:", Array.from(this.loadLast));
            console.log("Timeout set to:", this.timeout / 1000, "seconds");
        }

        //Setup bound functions, necessary for adding and removing 
        //listeners
        this.bound_start = this.beginDeferredLoading.bind(this);
        this.bound_restoreTemplates = () => {
            this.ensureTemplatesRestored('.unused-invisible-interaction-only');
            this.interactionEvents.forEach((event) => {
                window.removeEventListener(event, this.bound_restoreTemplates);
            });            
        };        
        this.boundTrackUserInteractions = this.captureUserInteraction.bind(this);
 
        if (this.attachListeners) {        

            //Add event listeners for our interaction events
            this.interactionEvents.forEach((event) => {
                window.addEventListener(event, this.bound_restoreTemplates, { passive: true, once: true });
                window.addEventListener(event, this.bound_start, { passive: true, once: true });                
            });

            //Track these events for replaying later
            if (window.speed_js_vars && window.speed_js_vars.trigger_replays === 'true') {
                if (this.debug) {
                    console.log("Enabling replay tracking...");
                }
                window.addEventListener("click", this.boundTrackUserInteractions, { passive: true });
                window.addEventListener("mouseover", this.boundTrackUserInteractions, { passive: true });
            }

        }

        // Set up timeout for delayed start
        setTimeout(this.bound_start, this.timeout);

    }
    
    /**
     * Ensure any delayed <template>-wrapped DOM has been restored
     * before we start executing deferred JS.
     */
    ensureTemplatesRestored(selector='.unused-invisible') {
        // Only check when there are candidates that could still be templates
        const needsRestore = !!document.querySelector(selector + ' > template');
        if (!needsRestore) {
            return;
        }

        if (this.debug) {
            console.log("Ensuring templates are restored before loading scripts...");
        }

        try {
            if (typeof window.restoreTemplateContentAndImages === "function") {
                // Prefer the existing helper if present
                window.restoreTemplateContentAndImages(selector);
                return;
            }

            // Minimal inline fallback if helper is not available yet
            document.querySelectorAll(selector).forEach((element) => {
                const firstChild = element.children[0];
                if (firstChild && firstChild.tagName === 'TEMPLATE') {
                    element.style.contentVisibility = '';
                    element.style.containIntrinsicSize = '';
                    const templateContent = firstChild.content.cloneNode(true);
                    element.replaceChild(templateContent, firstChild);
                }
            });
        } catch (err) {
            if (this.debug) {
                console.error("Error while restoring templates before JS load:", err);
            }
        }
    }    

    /**
     * Tracks user interactions and saves click or mouseover events.
     * @param {Event} event - User interaction event.
     */
    captureUserInteraction(event) {
        if (typeof event == "undefined") {
            return;
        }

        if (!window.speed_js_vars || window.speed_js_vars.trigger_replays !== 'true') {
            return;
        }        

        if (this.debug) {
            console.log("Tracking user interaction:", event);
        }

        if (event.type == "mouseover") {
            this.savedMouseovers.add(event);
        }

        if (event.type == "click") {
            this.savedClicks.add(event);
        }
    }

    /**
     * Begins the deferred loading process (after interaction or timeout).
     * @param {Event} event - User interaction event.
     */
    beginDeferredLoading(event) {

        if (this._loading) return;     // prevent concurrent runs

        if (this.debug) {
            console.log("Starting script loading process...", event);
        }

        //If this is a mouseover that can't exist, ignore
        if(typeof event != "undefined" && event.type == "mouseover" && matchMedia('(hover: hover)').matches == false) {
            return;
        }

        // Defer only while the document is *loading*. "interactive" is fine (DOMContentLoaded has fired).
        const domReady = document.readyState === "complete" || document.readyState === "interactive";
        if (!domReady) {
            if (!this._pendingDomReady) {
                this._pendingDomReady = true;
                if (this.debug) {
                    console.log("DOM not ready yet; waiting for DOMContentLoaded before loading scripts.");
                }
                document.addEventListener("DOMContentLoaded", this.bound_start, { once: true });
            }
            return;
        }  

        // Ensure templates are restored before running any deferred JS on the DOM.
        this.ensureTemplatesRestored();        
        
        this._loading = true; //prevent re-runs

        if (this.attachListeners) {
            this.interactionEvents.forEach((event) => {
                window.removeEventListener(event, this.bound_start);
            });
        }

        this.prewarmDeferredScripts();
        this.executeDeferredScripts();
    }

    /**
     *Prewarms deferred scripts by adding preload/modulepreload links.
     */
    prewarmDeferredScripts() {

        const scripts = this.collectDeferredNodesOrdered();
        if(scripts.length == 0) return;

        scripts.forEach((script) => {

            if (script.tagName === 'LINK') {

                const href = script.getAttribute('data-href');
                if (!href) return;

                if (this.debug) console.log('Restoring modulepreload:', href);

                script.setAttribute('href', href);
                script.removeAttribute('data-href');                

                if (script.hasAttribute('data-rel')) {
                    script.setAttribute('rel', script.getAttribute('data-rel'));
                    script.removeAttribute('data-rel');
                }                
            }

            if (script.tagName === 'SCRIPT') {

                const isModule = (script.getAttribute('type') || '').toLowerCase() === 'module';
                
                const src = script.getAttribute("data-src");
                if (!src || src === 'null' || src === 'undefined') return;

                // No point preloading inline data: URIs
                if (src.indexOf("data:") === 0) {
                    return;
                }                

                const link = document.createElement("link");

                if (isModule) {

                    link.rel = 'modulepreload';
                    link.href = src;

                    // Carry over attrs so fetch mode/credentials match the eventual module load
                    ['crossorigin', 'integrity', 'referrerpolicy'].forEach((attr) => {
                        if (script.hasAttribute(attr)) {
                            link.setAttribute(attr, script.getAttribute(attr));
                        }
                    });

                    if (this.debug) {
                        console.log('Modulepreloading:', src);
                    }

                } else {

                    link.rel = "preload";
                    link.as = "script";
                    link.href = src;

                    if (this.debug) {
                        console.log("Preloading scriptz:", src);
                    }

                }

                document.head.appendChild(link);

            }
        });
    }

    /**
     * Executes deferred scripts (in configured order)
     */
    executeDeferredScripts() {

        // Only pass runnable <script> nodes to the final loader
        const scriptsToLoad = this.collectDeferredNodesOrdered().filter((n) => n.tagName === 'SCRIPT');
        if(scriptsToLoad.length == 0) return;        

        this.runDeferredScriptQueue(scriptsToLoad);
    }

    /**
     * Determines the order of scripts to process based on `loadFirst` and `loadLast`.
     * @returns {Array} - Ordered list of script elements.
     */
    collectDeferredNodesOrdered() {
        const allScripts = this.sourceNodes
            ? [...this.sourceNodes]
            : [...document.querySelectorAll("script[data-src],link[data-rel='modulepreload']")];         

        const firstScripts = allScripts.filter((script) => {
            const dataSrc = script.getAttribute("data-src") || script.getAttribute("data-href");
            if (!dataSrc) return false;

            // Match any name in `this.loadFirst` against the full URL
            return Array.from(this.loadFirst).some((name) => dataSrc.includes(name));
        });

        const lastScripts = allScripts.filter((script) => {
            const dataSrc = script.getAttribute("data-src") || script.getAttribute("data-href");
            if (!dataSrc) return false;

            // Match any name in `this.loadLast` against the full URL
            return Array.from(this.loadLast).some((name) => dataSrc.includes(name));
        });

        const otherScripts = allScripts.filter((script) => {
            const dataSrc = script.getAttribute("data-src") || script.getAttribute("data-href");
            if (!dataSrc) return false;

            // Exclude scripts matched in `firstScripts` and `lastScripts`
            return !Array.from(this.loadFirst).some((name) => dataSrc.includes(name)) &&
                !Array.from(this.loadLast).some((name) => dataSrc.includes(name));
        });

        const scriptsToLoad = [...firstScripts, ...otherScripts, ...lastScripts];

        if (this.debug) {
            console.log("First scripts", firstScripts, this.loadFirst);
            console.log("Last scripts", lastScripts, this.loadLast);
            console.log("Scripts to load in order:", scriptsToLoad.map((script) => (script.getAttribute("data-src") || script.getAttribute("data-href"))));
        }


        return scriptsToLoad || 0;
    }

    /**
     * Replays captured DOM ready/load listeners registered while scripts were deferred.
     */
    replayDeferredDomEvents() {

        JsDelayer.capturing = false;
        JsDelayer.captureEvents.forEach((eventName) => {

            const listeners = JsDelayer.captured[eventName];
            if (!listeners || !listeners.length) return;

            listeners.forEach(({ target, listener, options }) => {
                try {
                    const ev = new Event(eventName, {
                        bubbles: true,
                        cancelable: true
                    });
                    listener.call(target, ev);
                    if (this.debug) {
                        console.log("Triggered", eventName, "listener for", listener, "on", target);
                    }
                } catch (err) {
                    if (this.debug) {
                        console.error("Error executing", eventName, "listener:", err);
                    }
                }
            });

            JsDelayer.captured[eventName] = [];
        });
    }


    /**
     * Loads scripts sequentially and triggers events after loading.
     * @param {Array} scripts - Array of script elements to load.
     */
    runDeferredScriptQueue(scripts) {


        const processScript = (index) => {
            if (index >= scripts.length) {

                // scripts finished: let any captured DOM ready/load handlers run
                this.replayDeferredDomEvents();

                if (!this.finalize) {
                    return;
                }

                //Dispatch event back to logged_in_exceptions worker
                document.dispatchEvent(new Event('delayedJSLoaded'));
                if (this.debug) {
                    console.log("All scripts loaded. Triggering events and replaying saved events...");
                }

                this.broadcastDeferredEvents().then(() => {                 

                    setTimeout(() => {
                        if (window.speed_js_vars && window.speed_js_vars.trigger_replays === 'true') {
                            if (this.debug) {
                                console.log("Replaying saved events...");
                            }
                            window.removeEventListener("mouseover", this.boundTrackUserInteractions, { passive: true });
                            window.removeEventListener("click", this.boundTrackUserInteractions, { passive: true });        
                            this.replayUserInteractions();
                        }
                    },100);
                    //Run the oncompleted JS
                    if(this.callback && this.callback_run === false) {
                        const callback = new Function(this.callback);
                        if(typeof callback === 'function') {
                            callback();
                            this.callback_run = true;
                        }
                    }
                    //Run again as it's possible new scripts have been added
                    var num_scripts = this.collectDeferredNodesOrdered().length;
                    if (this.debug) {
                        console.log("Rerunning script loader...",num_scripts);
                    }                
                    if(num_scripts > 0) {
                        this.bound_start(); 
                    }                    
                });  
                return;              
            }

            const node = scripts[index];

            // Skip anything that's not a <script>
            if (!node || node.tagName !== 'SCRIPT') {
                processScript(index + 1);
                return;
            }

            const src = node.getAttribute('data-src');

            // If we don't have a usable URL, skip WITHOUT writing back
            if (!src || src === 'null' || src === 'undefined') {
                if (this.debug) console.warn('Skipping script with invalid data-src:', node, src);
                processScript(index + 1);
                return;
            }

            node.onload  = () => {
                JsDelayer.capturing = false;
                processScript(index + 1);
            };
            node.onerror = () => {
                JsDelayer.capturing = false;
                processScript(index + 1);
            };

            JsDelayer.capturing = true;
            node.src = src;
            node.removeAttribute('data-src');
        };

        processScript(0);
    }

    /**
     * Broadcasts synthetic DOM/jQuery events after deferred scripts have executed.
     */
    broadcastDeferredEvents() {

        return new Promise((resolve) => {

            if (this.hasTriggeredEvents) {
                if (this.debug) {
                    console.log("triggerEvents already executed. Skipping...");
                }
                resolve();
                return;
            }

            this.hasTriggeredEvents = true;
            const cfg = window.speed_js_vars || {};

            // native broadcast
            if (cfg.trigger_native_broadcast) {
                const nb = cfg.trigger_native_broadcast;
                const map = { dom: "DOMContentLoaded", load: "load", readystate: "readystatechange" };
                const fire = (target, key) => {
                    Object.keys(map).forEach(kind => {
                        const col = nb[kind];
                        if (col && col[key] === "true") {
                            const evName = map[kind];
                            const ev = new Event(evName);
                            if (this.debug) {
                                console.log("Triggering native event:", evName, "on", key);
                            }
                            target.dispatchEvent(ev);
                        }
                    });
                };
                fire(window, "window");
                fire(document, "document");
            }

            // jQuery broadcast
            if (window.jQuery && typeof jQuery(document).get === "function" && cfg.trigger_jquery_broadcast) {
                const jb = cfg.trigger_jquery_broadcast;
                const run = (el, key) => {
                    const ev = jQuery._data(el, "events");
                    if (!ev) return;

                    if (jb.dom && jb.dom[key] === "true" && ev.ready) {
                        ev.ready.forEach(({ handler }) => {
                            if (this.debug) console.log("Triggering jQuery handler: ready", handler, "on", key);
                            handler(el);
                        });
                    }

                    if (jb.load && jb.load[key] === "true" && ev.load) {
                        ev.load.forEach(({ handler }) => {
                            if (this.debug) console.log("Triggering jQuery handler: load", handler, "on", key);
                            handler(el);
                        });
                    }
                };

               run(document, "document");
               run(window, "window");
            }

            resolve(); // Signal that triggerEvents has finished

        });

    }

    /**
     * Replays saved user interaction events.
     */
    replayUserInteractions() {

        if (this.debug) {
            console.log("Replaying clicks", this.savedClicks);
            console.log("Replaying mouseovers", this.savedMouseovers);
        }

        const replay = (events, type) => {
            events.forEach((event) => {
                events.delete(event);
                const target = event.target;
                if (this.debug) {
                    console.log("Replaying " + type + " event for target:", target);
                }
                if (target) {
                    const newEvent = new MouseEvent(type, {
                        view: event.view,
                        bubbles: true,
                        cancelable: true,
                    });
                    target.dispatchEvent(newEvent);
                }
            });
            events.clear();
        };

        replay(this.savedClicks, "click");
        replay(this.savedMouseovers, "mouseover");

    }
}

JsDelayer.ensurePatchedAddListener();

(function(){

window.speed_js_vars = window.speed_js_vars || {};
const loadFirst = (window.speed_js_vars.script_load_first  || '');
const loadLast  = (window.speed_js_vars.script_load_last   || '');

const allNodes = [...document.querySelectorAll("script[data-src],link[data-rel='modulepreload']")];
const delayedNodes = [...document.querySelectorAll("script[data-src][data-delay],link[data-rel='modulepreload'][data-delay]")];
const mainNodes = allNodes.filter((n) => !n.hasAttribute("data-delay"));

  const startDelayer = () => {
    
    //Main nodes
    new JsDelayer(loadFirst,loadLast,(window.speed_js_vars.delay_seconds || 6),(window.speed_js_vars.delay_callback || false),false,mainNodes,true,true);

    // Group scripts by absolute page-load delay
    const groups = new Map();
    delayedNodes.forEach((n) => {
        const d = parseFloat(n.getAttribute("data-delay"));
        if (!Number.isFinite(d) || d <= 0) return;
        if (!groups.has(d)) groups.set(d, []);
        groups.get(d).push(n);
    });

    // One instance per delay group: timeout-only start, load-only finalize
    groups.forEach((scripts, delaySeconds) => {
        new JsDelayer(loadFirst, loadLast, delaySeconds, false, false, scripts, false, false);
    });

  };

  //If we have logged in cached, then we must wait for
  //that to complete
  if(document.querySelectorAll(".spress_do_delay_js").length > 0) {
    // wait until the other script signals it's done
    // then fire on all nodes
    document.addEventListener('loggedInExceptionsDone', function() {
        new JsDelayer(loadFirst,loadLast,0.01,(window.speed_js_vars.delay_callback || false),false,allNodes,true,true);            
    }, { once: true });
    
  } else {
    // fire immediately
    if (document.prerendering === true) {
        window.speed_js_vars.delay_seconds = 0;
    }
    startDelayer();
  }
})();