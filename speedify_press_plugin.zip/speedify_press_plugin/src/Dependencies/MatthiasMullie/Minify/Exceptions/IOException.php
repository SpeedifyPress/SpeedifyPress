<?php

/**
 * IO Exception.
 *
 * Please report bugs on https://github.com/matthiasmullie/minify/issues
 *
 * @author Matthias Mullie <minify@mullie.eu>
 * @copyright Copyright (c) 2012, Matthias Mullie. All rights reserved
 * @license MIT License
 */

namespace SPRESS\Dependencies\MatthiasMullie\Minify\Exceptions;

/**
 * IO Exception Class.
 *
 * @author Matthias Mullie <minify@mullie.eu>
 */
class IOException extends BasicException {}
